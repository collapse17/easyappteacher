import React from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  TextInput,
  ActivityIndicator,
  Dimensions,
  Modal,
  Alert
    } from 'react-native';
import Reactotron from 'reactotron-react-native'
import {
  FormLabel,
  FormInput,
  FormValidationMessage,
  Divider,
  Card
} from 'react-native-elements'
import {
  create
} from 'apisauce'
import {ImagePicker} from 'expo';
import {
  Container,
  Content,
  List,
  ListItem,
  Text,
  Separator,
  Body,
  Header,
  Icon,
  Left,
  Right,
  Title,
  Tab,
  Tabs,
  Form,
  Button,
  Radio,
  Input,
  Item,
  Label} from 'native-base';
import Carousel from 'react-native-snap-carousel';
import LessonComponent from './components/LessonComponent.js'
export default class lessonsScreen extends React.Component {
  static navigationOptions = {
    title:'Уроки',
    header: null
    }
  constructor(props){
    super(props)
    this.state = { isLoading:true, lessons:[], attendancesModalIsVisible:false}
  }





  _renderItem ({item, index}) {
        return (
          <LessonComponent item={item}/>
        );
    }
  async componentDidMount(){
    await Expo.Font.loadAsync({
    'Roboto': require('native-base/Fonts/Roboto.ttf'),
    'Roboto_medium': require('native-base/Fonts/Roboto_medium.ttf'),
  }).then(()=>this.setState({isLoading:false}));
    const api = create({
     baseURL: "http://d.e-a-s-y.ru/api"
   })

  this.setState({
			lessons:[],isLoading:true
		});

         api.get('/lessons.json')
             // .then((response)=>console.log(response))
        //axios.get(`http://a.e-a-s-y.ru/api/lessons.json`, {withCrgb(237,63,67)entials:true})
        .then(res => {
            var data = res.data;
            //console.log(data.lessons);
            var less=[];
            less.push(data.lessons)
            less.push(data.lessons)
            console.log(less)
			this.setState({
                lessons: less,
                teachers: data["teachers"],
                isLoading:false,
            });

			if (data["lessons"].length === 0){
				this.setState({
	                empty:true,
	            });
			}

        })
        .catch((error) => {
            console.log(error);
			this.setState({
				empty:true,
			});
        });






  }
  render() {
    if (this.state.isLoading==true){return(<View style={{alignItems:'center', justifyContent:'center', flex:1}}><ActivityIndicator size='large'/></View>)}
    else{
    return (
      <Container style={{flex:1, backgroundColor:'white'}}>
      <Header transparent style={{backgroundColor:'white'}}>
          <Left style={{padding:10}}>
          <TouchableOpacity onPress={()=>this.props.navigation.openDrawer()}>
       <Icon name='menu' />
       </TouchableOpacity>
          </Left>
          <Body>
            <Title style={{color:'black'}}>Уроки</Title>
          </Body>
          <Right style={{padding:10}}>

              <Icon name='help'/>

          </Right>
        </Header>
      <Divider/>
      <View style={{alignItems:'center', flex:1}}>
      <Carousel style={{alignSelf:'center', paddingLeft:10}} layout={'default'} layoutCardOffset={18}
              ref={(c) => { this._carousel = c; }}
              data={this.state.lessons}
              renderItem={this._renderItem}
              sliderWidth={Dimensions.get('window').width}
              itemWidth={Dimensions.get('window').width-60}
            />
      </View>


      </Container>

    )}
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
