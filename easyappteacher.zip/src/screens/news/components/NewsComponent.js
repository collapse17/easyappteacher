import React from 'react'
import {Text, View, StyleSheet, ImageBackground, Modal, TouchableOpacity} from 'react-native'
import {LinearGradient} from 'expo';
import {
  Container,
  Content,
  List,
  ListItem,
  Body,
  Header,
  Icon,
  Left,
  Right,
  Title,
  Tab,
  Tabs,
  Form,
  Button,
  Radio,
  Input,
  Item,
  Label} from 'native-base';
  import {
    Divider,
    Card
  } from 'react-native-elements'
export default class NewsComponent extends React.Component {
  constructor(props){
    super(props)
    this.state = {moreIsVisible:false}
  }
  render(){
    const item = this.props.item;
    return(
      <View style={{flex:1
        }}>
        <Modal visible={this.state.moreIsVisible} onRequestClose={()=>this.setState({moreIsVisible:false})} transparent={true}>
        <View style={{backgroundColor:"white", flex:1, margin:40,borderRadius:20, borderLeftWidth:15,borderRightWidth:15, borderRightColor:'white', borderLeftColor:'rgb(237,63,67)'}}>
        <Header transparent style={{backgroundColor:'white'}}>
            <Left style={{padding:10}}>
            <TouchableOpacity onPress={()=>this.setState({moreIsVisible:false})}><Icon name='arrow-back' size={30} color='white'/></TouchableOpacity>
            </Left>
            <Body>
              <Title style={{color:'black', fontWeight:'bold'}}></Title>
            </Body>
          </Header>
          <Divider/>
          <Container style={{paddingLeft:10}}>
          <Text style={{fontSize:24,fontWeight:'bold'}}>{item.date}</Text>
          <Text style={{fontSize:30, fontWeight:'bold'}}>{item.title}</Text>
          <Text>{item.text}</Text>

                </Container>


        </View>
        </Modal>
        <TouchableOpacity style={{flex:1}} onPress={()=>this.setState({moreIsVisible:true})}>
          <ImageBackground source={require('../../../../assets/images/news-placeholder.png')} style={styles.backgroundImage}>
<LinearGradient colors={['transparent', '#C70505']} start={[2,0.4]} style={styles.linearGradient}>
<View style={{alignItems:'flex-end', flex:1, flexDirection:'row'}}>
<View style={{padding:30}}>
<Text style={{fontSize:24,fontWeight:'bold',color:'white'}}>{item.date}</Text>
<Text style={{fontSize:30, fontWeight:'bold',color:'white'}}>{item.title}</Text>

</View>
</View>
</LinearGradient>
          </ImageBackground>
          </TouchableOpacity>





      </View>)
  }
}
const styles = StyleSheet.create({
  linearGradient: {
    flex: 1,
    paddingLeft: 15,
    paddingRight: 15,
    borderRadius: 5,

  },

  backgroundImage: {
      flex: 1,
      width: null,
      height: null,
      borderRadius:10,
      borderWidth:4,
      borderColor:'gray'

  },
  overlay: {
    position: 'absolute',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    opacity: 0.3
  }
});
