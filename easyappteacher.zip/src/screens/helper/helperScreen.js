import React from 'react';
import { StyleSheet,
        TouchableOpacity,
         View,
        Image,
      TextInput,
    } from 'react-native';

import { FormLabel, FormInput, FormValidationMessage, Button } from 'react-native-elements'
import {create} from 'apisauce'
import { Container, Content, List, ListItem, Text, Separator, Body, Header,Icon, Left, Right, Title, Tab, Tabs } from 'native-base';

export default class helperScreen extends React.Component {
  static navigationOptions = {
    title:'Отчеты',
    header: null
    }
  constructor(props){
    super(props)
    this.state = { isLoading:true}
  }
  async componentDidMount(){
    await Expo.Font.loadAsync({
    'Roboto': require('native-base/Fonts/Roboto.ttf'),
    'Roboto_medium': require('native-base/Fonts/Roboto_medium.ttf'),
  }).then(()=>this.setState({isLoading:false}));
    //const api = create({
    //  baseURL: "http://d.e-a-s-y.ru/api"
  //  })
  //  api.get('groups.json',{api_user:{email:this.state.login,password:this.state.password}})
  //      .then((response)=>console.log(response))
  }
  render() {
    if (this.state.isLoading==true){return(<View></View>)}
    else
    return (
      <Container style={{flex:1, backgroundColor:'white'}}>
      <Header transparent style={{backgroundColor:'white'}}>
          <Left style={{padding:10}}>
          <TouchableOpacity onPress={()=>this.props.navigation.openDrawer()}>
       <Icon name='menu' />
       </TouchableOpacity>
          </Left>
          <Body>
            <Title style={{color:'black'}}>Хелпер</Title>
          </Body>
          <Right style={{padding:10}}>

              <Icon name='help'/>

          </Right>
        </Header>
      <Text>ReportScreen</Text>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
